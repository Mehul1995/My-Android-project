package com.example.user.myproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        String msg = "";

        switch (item.getItemId()) {

            case R.id.tab1:
                msg = getString(R.string.tab_one);
                Intent intent_tabone = new Intent(this,TabOne.class);
                startActivity(intent_tabone);
                break;


            case R.id.tab2:
                msg = getString(R.string.tab_two);
                Intent intent_tabtwo = new Intent(this,TabTwo.class);
                startActivity(intent_tabtwo);
                break;


            case R.id.settings:
                msg = getString(R.string.settings);
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);
                break;


            case R.id.Exit:
                msg = getString(R.string.exit);
                Intent intentexit = new Intent(Intent.ACTION_MAIN);
                intentexit.addCategory(Intent.CATEGORY_HOME);
                intentexit.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intentexit);
                break;
        }

        Toast.makeText(this, msg + " clicked!!", Toast.LENGTH_SHORT).show();

        return super.onOptionsItemSelected(item);
    }


}
