package com.example.user.myproject;

import android.app.AlertDialog;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class TabOne extends AppCompatActivity {


    EditText E1,E2,E3;
    RadioButton R1,R2,R3,R4;
    DBHelper_tabone mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab_one);
        setTitle("Tab One");

        mydb=new DBHelper_tabone(this);
        E1=(EditText)findViewById(R.id.editText);
        E2=(EditText)findViewById(R.id.editText2);
        E3=(EditText)findViewById(R.id.editText3);

        R1=(RadioButton)findViewById(R.id.radioButton);
        R2=(RadioButton)findViewById(R.id.radioButton2);
        R3=(RadioButton)findViewById(R.id.radioButton3);
        R4=(RadioButton)findViewById(R.id.radioButton4);
    }



    public void insert(View view) {

        mydb.insertdata(E1.getText().toString(), E2.getText().toString(), E3.getText().toString(), R1.getText().toString(),
                R2.getText().toString(), R3.getText().toString(), R4.getText().toString());
        Toast.makeText(this," Input taken ",Toast.LENGTH_LONG).show();
    }

    public void clear(View view) {

        E1.setText("");
        E2.setText("");
        E3.setText("");
        R1.clearComposingText();
        R2.clearComposingText();
        R3.clearComposingText();
        R4.clearComposingText();

    }

    public void viewdata(View view) {

        Cursor c = mydb.getalldata();
        if(c.getCount()==0){

            showdialogue(" Alert !!"," No Data Found !!");
        }
        else
        {
            StringBuffer bf = new StringBuffer();
            while(c.moveToNext()){

                bf.append("T-shirt Name : "+c.getString(0)+"\n");
                bf.append("Brand Name : "+c.getString(1)+"\n");
                bf.append("Cost : Rs "+c.getString(2)+"\n");
                bf.append("Price for: "+c.getString(6)+"\n");
            }

            showdialogue(" Data ", bf.toString());
        }
    }

    public void showdialogue(String title,String msg){

        AlertDialog.Builder bu = new AlertDialog.Builder(this);
        bu.setCancelable(true);
        bu.setTitle(title);
        bu.setMessage(msg);
        bu.show();
    }

}
