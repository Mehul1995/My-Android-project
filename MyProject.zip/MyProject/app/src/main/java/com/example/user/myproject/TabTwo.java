package com.example.user.myproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class TabTwo extends Activity implements AdapterView.OnItemSelectedListener {

    Button btn;
    Spinner S1,S2,S3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab_two);
        setTitle("Tab Two");


        // Spinner 1
        Spinner spinner = (Spinner) findViewById(R.id.tshirt_name_dropdown);
        spinner.setOnItemSelectedListener(this);
        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("Men");
        categories.add("Women");
        categories.add("Kids");
        categories.add("Infants");
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);



        // Spinner 2
        Spinner spinner2 = (Spinner) findViewById(R.id.brand_dropdown);
        spinner2.setOnItemSelectedListener(this);
        // Spinner Drop down elements
        List<String> categories2 = new ArrayList<String>();
        categories2.add("Lee Cooper");
        categories2.add("Levis");
        categories2.add("United Colors of Benetton");
        categories2.add("Wrangler");
        // Creating adapter for spinner 2
        ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories2);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter2);



        // Spinner 3
        Spinner spinner3 = (Spinner) findViewById(R.id.pricelist_dropdown);
        spinner3.setOnItemSelectedListener(this);
        // Spinner Drop down elements
        List<String> categories3 = new ArrayList<String>();
        categories3.add("Rs 799");
        categories3.add("Rs 999");
        categories3.add("Rs 1299");
        categories3.add("Rs 1599");
        // Creating adapter for spinner 3
        ArrayAdapter<String> dataAdapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories3);
        dataAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(dataAdapter3);


        btn = (Button)findViewById(R.id.sub);
        S1 =(Spinner)findViewById(R.id.tshirt_name_dropdown);
        S2=(Spinner)findViewById(R.id.brand_dropdown);
        S3=(Spinner)findViewById(R.id.pricelist_dropdown);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
    }
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    public void submit(View view) {

        Intent i = new Intent(this, Pc.class);
        startActivity(i);
    }
}
