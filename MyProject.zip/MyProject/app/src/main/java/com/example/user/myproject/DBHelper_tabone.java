package com.example.user.myproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by user on 11/5/16.
 */
public class DBHelper_tabone extends SQLiteOpenHelper {

    public static final String DATABASE_NAME="value.db";

    public DBHelper_tabone(Context context){

        super(context,DATABASE_NAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table value(tshirt_name TEXT,brand_name TEXT,size1 TEXT,size2 TEXT,size3 TEXT,size4 TEXT,price TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS value");
        onCreate(db);
    }

    public void insertdata(String tname,String bname,String siz1,String siz2,String siz3,String siz4,String pric){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv= new ContentValues();
        cv.put("tshirt_name",tname);
        cv.put("brand_name",bname);
        cv.put("size1",siz1);
        cv.put("size2",siz2);
        cv.put("size3",siz3);
        cv.put("size4",siz4);
        cv.put("price", pric);
        db.insert("value", null, cv);
    }


    public Cursor getalldata()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res= db.rawQuery("select * from value",null);
        return res;

    }


}
